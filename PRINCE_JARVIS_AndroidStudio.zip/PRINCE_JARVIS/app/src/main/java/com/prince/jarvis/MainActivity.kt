package com.prince.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.media.AudioManager
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var torchOn = false
    private val requestAudio = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(10, 16, 28))
        }
        val title = TextView(this).apply {
            text = "PRINCE JARVIS"
            textSize = 30f
            setTextColor(Color.rgb(70, 205, 255))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Namaste! Main aapka assistant hoon."
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val talk = makeButton("🎙  BOLKAR COMMAND DO") { startListening() }
        val apps = makeButton("YouTube kholo") { launchPackage("com.google.android.youtube") }
        val chrome = makeButton("Chrome kholo") { launchPackage("com.android.chrome") }
        val flash = makeButton("Flashlight ON / OFF") { toggleTorch() }
        val volume = makeButton("Volume badhao") {
            (getSystemService(AUDIO_SERVICE) as AudioManager)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            say("Volume badha diya.")
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(talk)
        layout.addView(apps)
        layout.addView(chrome)
        layout.addView(flash)
        layout.addView(volume)
        setContentView(layout)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Is phone par speech recognition available nahi hai."
            say("Speech recognition available nahi hai.")
            return
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Sun raha hoon..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Samajh raha hoon..." }
            override fun onError(error: Int) { status.text = "Awaaz samajh nahi aayi. Dobara try karo."; recognizer.destroy() }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                status.text = "Aapne kaha: $words"
                handleCommand(words.lowercase(Locale.ROOT))
                recognizer.destroy()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis ko command dein")
        }
        recognizer.startListening(intent)
    }

    private fun handleCommand(command: String) {
        when {
            "youtube" in command -> launchPackage("com.google.android.youtube")
            "chrome" in command || "browser" in command -> launchPackage("com.android.chrome")
            "flash" in command || "torch" in command || "टॉर्च" in command -> toggleTorch()
            "volume" in command || "आवाज" in command -> {
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI
                )
                say("Volume badha diya.")
            }
            "call" in command || "फोन" in command -> {
                val number = command.filter { it.isDigit() || it == '+' }
                if (number.length >= 5) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                    say("Dialer khol raha hoon. Call karne se pehle number check kar lena.")
                } else say("Call ke liye abhi number ko dialer mein manually enter karein.")
            }
            else -> say("Yeh command abhi meri list mein nahi hai.")
        }
    }

    private fun launchPackage(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) startActivity(intent) else say("Yeh app phone mein nahi mili.")
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { say("Flashlight available nahi hai."); return }
            torchOn = !torchOn
            manager.setTorchMode(cameraId, torchOn)
            say(if (torchOn) "Flashlight on." else "Flashlight off.")
        } catch (_: Exception) { say("Flashlight control nahi ho paya.") }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
